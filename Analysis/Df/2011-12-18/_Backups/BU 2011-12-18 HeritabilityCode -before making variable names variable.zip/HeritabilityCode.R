rm(list=ls(all=TRUE)) #Clear all the variables before starting a new run.

#################################################################################################
# Exclude some observations, define some constants and desfine a helper function
#################################################################################################
pathDoubleEntered <- "F:/Projects/Nls/Links2011/Analysis/Df/2011-12-18/DoubleEntered.csv"
ageFloorInclusive <- 19
ambiguousImplicitSiblingR <- .375
zScoreThreshold <- 10
 
ds <- read.csv(pathDoubleEntered)

#Cut the youngins
ds <- subset(ds, AgeHt1>=ageFloorInclusive & AgeHt2>=ageFloorInclusive)
#Set the remaining ambiguous pairs to an fixed constant.
ds[is.na(ds$R), "R"] <- ambiguousImplicitSiblingR
#Cut the ambiguous
ds <- subset(ds, R!=.375)

#Include people if their zScores aren't too high
ds <- subset(ds, -zScoreThreshold<=HtSt1 & HtSt1<=zScoreThreshold)
ds <- subset(ds, -zScoreThreshold<=HtSt2 & HtSt2<=zScoreThreshold)

ExtractHeightHeritabilitiesMethod1 <- function( dsLm ) {
  #dsLm <- subset(ds, !is.na(HtSt1) & !is.na(HtSt2) & !is.na(R))
  
  brief <- summary(lm(HtSt1 ~ 1 + HtSt2 + R + HtSt2*R, data=dsLm))
  coeficients <- coef(brief)
  nDouble <- length(brief$residuals) 
  #b0 <- coeficients["(Intercept)", "Estimate"]
  b1 <- coeficients["HtSt2", "Estimate"]  
  #b2 <- coeficients["R", "Estimate"]
  b3 <- coeficients["HtSt2:R", "Estimate"]

  return( list(HSquared=b3, CSquared=b1, NDouble=nDouble) )
}
ExtractHeightHeritabilitiesMethod2 <- function( dsLm ) {
  #dsLm <- subset(ds, !is.na(HtSt1) & !is.na(HtSt2) & !is.na(R))
  sampleMean <- mean(dsLm$HtSt1, na.rm=T)
  
  brief <- summary(lm(HtSt1 ~ 1 + HtSt2 + R + HtSt2*R, data=dsLm))
  coeficients <- coef(brief)
  nDouble <- length(brief$residuals) 
  b0 <- coeficients["(Intercept)", "Estimate"]
  #b1 <- coeficients["HtSt2", "Estimate"]  
  b2 <- coeficients["R", "Estimate"]
  #b3 <- coeficients["HtSt2:R", "Estimate"]
  
  hSquared <- -b2/sampleMean
  cSquared <- 1 - (b0/sampleMean)
  return( list(HSquared=hSquared, CSquared=cSquared, NDouble=nDouble) )
}
ExtractHeightHeritabilitiesMethod3 <- function( dsLm ) {
  #dsLm <- subset(ds, !is.na(HtSt1) & !is.na(HtSt2) & !is.na(R))
  sampleMean <- mean(dsLm$HtSt1, na.rm=T)
  dsLm$Dv2Centered <- dsLm$HtSt2 - sampleMean
  dsLm$Interaction <- dsLm$Dv2Centered*dsLm$R
  
  brief <- summary(lm(HtSt1 ~ 0 + Dv2Centered + Interaction, data=dsLm)) #The '0' specifies and intercept-free model.
  coeficients <- coef(brief)
  nDouble <- length(brief$residuals) 
  b1 <- coeficients["Dv2Centered", "Estimate"]  
  b2 <- coeficients["Interaction", "Estimate"]
  return( list(HSquared=b2, CSquared=b1, NDouble=nDouble) )
}

ExtractHeightResults <- function( dsSubset, subsetTitle ) {
  #dsSubset <- ds
  #subsetTitle <- "TestingEveryone"
  dsLm <- subset(dsSubset, !is.na(HtSt1) & !is.na(HtSt2) & !is.na(R))
  #heritablities <- ExtractHeightHeritabilitiesMethod1(dsLm) #Method 1 (original DF that uses b1 & b3)
  #heritablities <- ExtractHeightHeritabilitiesMethod2(dsLm) #Method 2 (rescale of b0 & b2)
  heritablities <- ExtractHeightHeritabilitiesMethod3(dsLm) #Method 3 (Simplified DF -Rodgers & Kohler, 2005)
  
  nDouble <- heritablities$NDouble
  hSquared <- heritablities$HSquared
  cSquared <- heritablities$CSquared
  eSquared <- 1 - hSquared - cSquared
  
  countHalf <- sum(dsLm$R == .25)
  countAmbiguousSib <- sum(dsLm$R == .375)
  countFull <- sum(dsLm$R == .5)
  countAmbiguousTwin <- sum(dsLm$R == .75)
  countMz <- sum(dsLm$R == 1)
  
  corHalf <- cor(dsLm$HtSt1[dsLm$R == .25], dsLm$HtSt2[dsLm$R == .25])
  corAmbiguousSib <- cor(dsLm$HtSt1[dsLm$R == .375], dsLm$HtSt2[dsLm$R == .375])
  corFull <- cor(dsLm$HtSt1[dsLm$R == .5], dsLm$HtSt2[dsLm$R == .5])
  #corAmbiguousTwin <- cor(dsLm$HtSt1[dsLm$R == .75], dsLm$HtSt2[dsLm$R == .75])
  corMz <- cor(dsLm$HtSt1[dsLm$R == 1], dsLm$HtSt2[dsLm$R == 1])
  
  dsResult <- data.frame(Subgroup=subsetTitle,NDouble=nDouble, HSq=hSquared, CSq=cSquared, ESq=eSquared,
    M=mean(dsLm$HtSt1, na.rm=T), SD=sd(dsLm$HtSt1, na.rm=T), Skew=skewness(dsLm$HtSt1, na.rm=T),
    Half=countHalf, AS=countAmbiguousSib, Full=countFull, AT=countAmbiguousTwin, Mz=countMz,
    CorHalf=corHalf, CorAS=corAmbiguousSib, CorFull=corFull, CorMz=corMz #CorAT=corAmbiguousTwin,                         
  )  
  return( dsResult )
}
PrintDescriptivesTable <- function( dsResults, title="" ) {
  colnames(dsResults) <- c("Subgroup", "$N$", "$h^2$", "$c^2$", "$e^2$", #17 columns
                       "$\\bar{X}$", "$\\sigma$", "$\\sigma^3$",
                       "$N_{.25}$", "$N_{.375}$", "$N_{.5}$", "$N_{.75}$", "$N_{Mz}$",
                       "$r_{.25}$", "$r_{.375}$", "$r_{.5}$",              "$r_{Mz}$") #, "$r_{.75}$" 
  
  #Set the formatting for the table
  digitsFormat <- c(0,0,0, 2,2,2, 2,2,2, 0,0,0,0,0, 2,2,2,2)  #Include an initial dummy for the (suprressed) row names; drop r75.
  textTable <-  xtable(dsResults, caption="Height Heritability", label="tab:two", digits=digitsFormat)
  align(textTable) <- "llr|rrr|rrr|rrrrr|rrrr"  #Include an initial dummy for the (suprressed) row names; drop r75.
  hLineLocations <- c(1, 4, 7, 10, 13)
  
  print(textTable, hline.after=hLineLocations, include.rownames=F, sanitize.text.function = function(x) {x})  
}

PrintDescriptivesTableFewerColumns <- function( dsResults, title="" ) {
  dsResults <- dsResults[, c(1, 3:5, 9:13, 14:17)]
  colnames(dsResults) <- c("Subgroup",  "$h^2$", "$c^2$", "$e^2$", 
                       "$N_{.25}$", "$N_{.375}$", "$N_{.5}$", "$N_{.75}$", "$N_{Mz}$",
                       "$r_{.25}$", "$r_{.375}$", "$r_{.5}$", "$r_{Mz}$")
  textTable <-  xtable(dsResults)#, , digits=digitsFormat)
  align(textTable) <- "ll|rrr|rrrrr|rrrr"  #Include an initial dummy for the (suprressed) row names.
  hLineLocations <- c(1)
  #print(textTable,include.rownames=F, sanitize.text.function = function(x) {x})
  print(textTable, hline.after=hLineLocations, include.rownames=F, sanitize.text.function = function(x) {x})
  
  
}

#################################################################################################
# Define the subgroups
#################################################################################################
#By Gender
dsFF <- subset(ds, CGender1==2 & CGender2==2)
dsMF <- subset(ds, CGender1!=CGender2)
dsMM <- subset(ds, CGender1==1 & CGender2==1)

#By Race (1:Hispanic, 2:Black, 3:NBNH)
dsHispanic <- subset(ds, CRace1==1)
dsBlack <- subset(ds, CRace1==2)
dsNBNH <- subset(ds, CRace1==3)

#By Gender for Hispanics
dsHispanicFF <- subset(ds, CRace1==1 & CGender1==2 & CGender2==2)
dsHispanicMF <- subset(ds, CRace1==1 & CGender1!=CGender2)
dsHispanicMM <- subset(ds, CRace1==1 & CGender1==1 & CGender2==1)

#By Gender for Blacks
dsBlackFF <- subset(ds, CRace1==2 & CGender1==2 & CGender2==2)
dsBlackMF <- subset(ds, CRace1==2 & CGender1!=CGender2)
dsBlackMM <- subset(ds, CRace1==2 & CGender1==1 & CGender2==1)

#By Gender for NBNHs
dsNBNHFF <- subset(ds, CRace1==3 & CGender1==2 & CGender2==2)
dsNBNHMF <- subset(ds, CRace1==3 & CGender1!=CGender2)
dsNBNHMM <- subset(ds, CRace1==3 & CGender1==1 & CGender2==1)
 
#################################################################################################
# Get the results for the table
#################################################################################################
resultTotal <- ExtractHeightResults(dsSubset=ds, subsetTitle="Total")
#By Gender
resultFF <- ExtractHeightResults(dsSubset=dsFF, subsetTitle="FF")
resultMF <- ExtractHeightResults(dsSubset=dsMF, subsetTitle="MF")
resultMM <- ExtractHeightResults(dsSubset=dsMM, subsetTitle="MM")

#By Race (1:Hispanic, 2:Black, 3:NBNH)
resultHispanic <- ExtractHeightResults(dsSubset=dsHispanic, subsetTitle="Hispanic")
resultBlack <- ExtractHeightResults(dsSubset=dsBlack, subsetTitle="Black")
resultNBNH <- ExtractHeightResults(dsSubset=dsNBNH, subsetTitle="NBNH")

#By Gender for Hispanics
resultHispanicFF <- ExtractHeightResults(dsSubset=dsHispanicFF, subsetTitle="Hisp FF")
resultHispanicMF <- ExtractHeightResults(dsSubset=dsHispanicMF, subsetTitle="Hisp MF")
resultHispanicMM <- ExtractHeightResults(dsSubset=dsHispanicMM, subsetTitle="Hisp MM")

#By Gender for Blacks
resultBlackFF <- ExtractHeightResults(dsSubset=dsBlackFF, subsetTitle="Black FF")
resultBlackMF <- ExtractHeightResults(dsSubset=dsBlackMF, subsetTitle="Black MF")
resultBlackMM <- ExtractHeightResults(dsSubset=dsBlackMM, subsetTitle="Black MM")

#By Gender for NBNHs
resultNBNHFF <- ExtractHeightResults(dsSubset=dsNBNHFF, subsetTitle="NBNH FF")
resultNBNHMF <- ExtractHeightResults(dsSubset=dsNBNHMF, subsetTitle="NBNH MF")
resultNBNHMM <- ExtractHeightResults(dsSubset=dsNBNHMM, subsetTitle="NBNH MM")

results <- rbind(
  resultTotal,  resultFF, resultMF, resultMM,
  resultHispanic, resultBlack, resultNBNH, 
  resultHispanicFF, resultHispanicMF, resultHispanicMM,
  resultBlackFF, resultBlackMF, resultBlackMM,
  resultNBNHFF, resultNBNHMF, resultNBNHMM
  )





###
### Get the results for the graphs
###
rCategoryCount <- length(unique(ds$R))
PlotSubgroup <- function( dsSubgroup, title, showLoess=T, sectionTitle=""){
  lmcoef <- coef(lm(HtSt2 ~ HtSt1, dsSubgroup))
  dvRange <- c(-6.5, 4.5)
  gridLineLocations <- pretty(dvRange)
  p <- ggplot(dsSubgroup) #HtSt2 ~ HtSt1 | R, data=

  if( showLoess ) {
    p + stat_binhex(aes(x=HtSt1, y=HtSt2), binwidth = c(1, 1) ) +  
      geom_smooth(aes(x=HtSt1, y=HtSt2), method="loess", size = 1.5, col="green") +
      geom_abline(intercept=lmcoef[1], slope=lmcoef[2], col="tomato") +
      geom_smooth(aes(x=HtSt1, y=HtSt2), method="lm", se=F, col="gold") +
      facet_grid(.~ R) + opts(aspect.ratio=1) + 
      scale_x_continuous(title, breaks=gridLineLocations)+ scale_y_continuous(sectionTitle, breaks=gridLineLocations) + # coord_equal(ratio = 1)
      coord_cartesian(xlim=dvRange, ylim=dvRange) 
      #coord_cartesian(xlim=dvRange), ylim=dvRange)
    #+opts(aspect.ratio=1, title=title) +
  }
  else {
    p + stat_binhex(aes(x=HtSt1, y=HtSt2), binwidth = c(1, 1) ) +  
      geom_abline(intercept=lmcoef[1], slope=lmcoef[2], col="tomato") +
      geom_smooth(aes(x=HtSt1, y=HtSt2), method="lm", se=F, col="gold") +
      facet_grid(.~ R) + opts(aspect.ratio=1) + 
      scale_x_continuous(title, breaks=gridLineLocations)+ scale_y_continuous(sectionTitle, breaks=gridLineLocations) + # coord_equal(ratio = 1)
      coord_cartesian(xlim=dvRange, ylim=dvRange)   
  }

  #coord_cartesian(xlim=range(ds$HtSt1), ylim=range(ds$HtSt2))
  #p + geom_density(aes(x=HtSt1, y=HtSt2), data)
}



