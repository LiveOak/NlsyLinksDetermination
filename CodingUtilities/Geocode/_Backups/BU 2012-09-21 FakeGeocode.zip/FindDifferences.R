rm(list=ls(all=TRUE)) #Clear any old variables from the R session's memory.
# install.packages("NlsyLinks") #Install the NlsyLinks package, if it's not already installed.
library(NlsyLinks) #Load the package into memory.

#Declare the locations of the datasets to read and write.
pathIn <- "F:/Projects/Nls/Links2011/CodingUtilities/Geocode/FakeGeocode.csv"
pathOut <- "F:/Projects/Nls/Links2011/CodingUtilities/Geocode/Sanitized.csv"

#Extract the pairs of subjects related in the first generation.
ds <- Links79Pair[Links79Pair$RelationshipPath=="Gen1Housemates", ]

#Read in the geocode dataset & create a variable to merge with.
dsGeocode <- read.csv(file=pathIn, stringsAsFactors=FALSE)
dsGeocode$SubjectTag <- dsGeocode$SubjectID * 100

#Merge the geocode responses of the 'left' subject (ie, the one with the smaller ID); rename some columns.
#   When using the real geocode dataset, these five columns will need to be chagned to reflect the R/variable numbers.
ds <- merge(x=ds, y=dsGeocode, by.x="Subject1Tag", by.y="SubjectTag")
colnames(ds)[colnames(ds)=="SubjectID"] <- "SubjectID_1"
colnames(ds)[colnames(ds)=="Dob"] <- "Dob_1"
colnames(ds)[colnames(ds)=="BirthCountySubject"] <- "BirthCountySubject_1"
colnames(ds)[colnames(ds)=="BirthStateSubject"] <- "BirthStateSubject_1"
colnames(ds)[colnames(ds)=="BirthStateMother"] <- "BirthStateMother_1"
colnames(ds)[colnames(ds)=="BirthStateFather"] <- "BirthStateFather_1"

#Merge the geocode responses of the 'right' subject (ie, the one with the larger ID); rename some columns.
ds <- merge(x=ds, y=dsGeocode, by.x="Subject2Tag", by.y="SubjectTag")
colnames(ds)[colnames(ds)=="SubjectID"] <- "SubjectID_2"
colnames(ds)[colnames(ds)=="Dob"] <- "Dob_2"
colnames(ds)[colnames(ds)=="BirthCountySubject"] <- "BirthCountySubject_2"
colnames(ds)[colnames(ds)=="BirthStateSubject"] <- "BirthStateSubject_2"
colnames(ds)[colnames(ds)=="BirthStateMother"] <- "BirthStateMother_2"
colnames(ds)[colnames(ds)=="BirthStateFather"] <- "BirthStateFather_2"

#Calculate the number of days in between their birthdays
ds$DobDifferenceInDays <- difftime(ds$Dob_1, ds$Dob_2, units="days")

#Declare the responses that we don't want to compare
missingCategories <- c("Invalid Skip", "Refused")

#Find differences for the subjects' places of birth (county and state).
ds$BirthCountySubjectMissing_1 <- (ds$BirthCountySubject_1 %in% missingCategories)
ds$BirthCountySubjectMissing_2 <- (ds$BirthCountySubject_2 %in% missingCategories)
ds$BirthCountySubjectEqual <- (ds$BirthCountySubject_1 == ds$BirthCountySubject_2)

ds$BirthStateSubjectMissing_1 <- (ds$BirthStateSubject_1 %in% missingCategories)
ds$BirthStateSubjectMissing_2 <- (ds$BirthStateSubject_2 %in% missingCategories)
ds$BirthStateSubjectEqual <- (ds$BirthStateSubject_1 == ds$BirthStateSubject_2)

#Find differences for the mothers' places of birth (only state).
ds$BirthStateMotherMissing_1 <- (ds$BirthStateMother_1 %in% missingCategories)
ds$BirthStateMotherMissing_2 <- (ds$BirthStateMother_2 %in% missingCategories)
ds$BirthStateMotherEqual <- (ds$BirthStateMother_1 == ds$BirthStateMother_2)

#Find differences for the fathers' places of birth (only state).
ds$BirthStateFatherMissing_1 <- (ds$BirthStateFather_1 %in% missingCategories)
ds$BirthStateFatherMissing_2 <- (ds$BirthStateFather_2 %in% missingCategories)
ds$BirthStateFatherEqual <- (ds$BirthStateFather_1 == ds$BirthStateFather_2)

#Declare the 15 columns that have no potentially identifying information.
sanitizedColumnNames <- c(
  "Subject1Tag", "Subject2Tag", 
  "DobDifferenceInDays", 
  "BirthCountySubjectMissing_1", "BirthCountySubjectMissing_2", "BirthCountySubjectEqual",
  "BirthStateSubjectMissing_1", "BirthStateSubjectMissing_2", "BirthStateSubjectEqual",
  "BirthStateMotherMissing_1", "BirthStateMotherMissing_2", "BirthStateMotherEqual",
  "BirthStateFatherMissing_1", "BirthStateFatherMissing_2", "BirthStateFatherEqual"
)

#Select only the sanitized variables.
dsSanitized <- ds[, sanitizedColumnNames]

#Save the dataset to a CSV on the CHRR's local workstation (which then will be manually emailed to Joe Rodgers).
write.csv(x=dsSanitized, file=pathOut, row.names=FALSE)