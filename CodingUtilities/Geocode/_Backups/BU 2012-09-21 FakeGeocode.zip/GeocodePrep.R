rm(list=ls(all=TRUE))
library(NlsyLinks)
library(lubridate)
# dsLinksGen1 <- Links79Pair[Links79Pair$RelationshipPath=="Gen1Housemates", ]
pathOut <- "F:/Projects/Nls/Links2011/CodingUtilities/Geocode/FakeGeocode.csv"


dobStart <- ISOdate(1957, 1, 1)
dobStop <- ISOdate(1964, 12, 31)

dsSubjectGen1 <- data.frame(
  SubjectID=SubjectDetails79[SubjectDetails79$Generation==1, ]$SubjectTag/100, 
  Dob=ISOdate(1900, 1,1),
  BirthCountySubject=NA_character_,
  BirthStateSubject=NA_character_,
  BirthStateMother=NA_character_,
  BirthStateFather=NA_character_
)
n <- nrow(dsSubjectGen1)


dobDurationInDays <- as.integer(dobStop - dobStart)
dsSubjectGen1$Dob <- dobStart + as.difftime(floor(runif(n=n, min=0, max=dobDurationInDays)), units="days")

potentialStates <- c("Oklahoma", "Maine", "Florida", "New York", "Illinois", "Invalid Skip", "Refused")
potentialCounties <- c("Cleveland", "Rogers", "Bard", "Hunter", "Meredith")


dsSubjectGen1$BirthCountySubject <- potentialCounties[floor(runif(n, min=1, max=length(potentialCounties)))]
dsSubjectGen1$BirthStateSubject <- potentialStates[floor(runif(n, min=1, max=length(potentialStates)))]
dsSubjectGen1$BirthStateMother <- potentialStates[floor(runif(n, min=1, max=length(potentialStates)))]
dsSubjectGen1$BirthStateFather <- potentialStates[floor(runif(n, min=1, max=length(potentialStates)))]


write.csv(dsSubjectGen1, file=pathOut, row.names=FALSE)