rm(list=ls(all=TRUE))
library(RODBC)
library(plyr)
library(xtable)
library(ggplot2)
includedRelationshipPaths <- c(2)
# includedRelationshipPaths <- c(1)
# includedRelationshipPaths <- c(1, 2)

#sqlTopTwo <- "SELECT Top 2 AlgorithmVersion FROM NlsLinks.Process.tblRelatedValuesArchive GROUP BY AlgorithmVersion ORDER BY AlgorithmVersion DESC"
#sql <- "SELECT * FROM NlsLinks.Process.tblRelatedValuesArchive WHERE AlgorithmVersion in (SELECT Top 2 AlgorithmVersion FROM NlsLinks.Process.tblRelatedValuesArchive GROUP BY AlgorithmVersion ORDER BY AlgorithmVersion DESC)"
#sql <- "SELECT * FROM NlsLinks.Process.tblItem"
sql <- paste("SELECT Process.tblRelatedValuesArchive.ID, Process.tblRelatedValuesArchive.AlgorithmVersion, Process.tblRelatedStructure.RelationshipPath, Process.tblRelatedValuesArchive.Subject1Tag, Process.tblRelatedValuesArchive.Subject2Tag, Process.tblRelatedValuesArchive.MultipleBirth, Process.tblRelatedValuesArchive.IsMz, Process.tblRelatedValuesArchive.Subject1LastSurvey, Process.tblRelatedValuesArchive.Subject2LastSurvey, Process.tblRelatedValuesArchive.RImplicitPass1, Process.tblRelatedValuesArchive.RImplicit, Process.tblRelatedValuesArchive.RImplicitSubject, Process.tblRelatedValuesArchive.RImplicitMother, Process.tblRelatedValuesArchive.RImplicit2004, Process.tblRelatedValuesArchive.RExplicitOldestSibVersion, Process.tblRelatedValuesArchive.RExplicitYoungestSibVersion, Process.tblRelatedValuesArchive.RExplicitPass1, Process.tblRelatedValuesArchive.RExplicit, Process.tblRelatedValuesArchive.RPass1, Process.tblRelatedValuesArchive.R, Process.tblRelatedValuesArchive.RPeek 
  FROM Process.tblRelatedValuesArchive INNER JOIN Process.tblRelatedStructure ON Process.tblRelatedValuesArchive.Subject1Tag = Process.tblRelatedStructure.Subject1Tag AND Process.tblRelatedValuesArchive.Subject2Tag = Process.tblRelatedStructure.Subject2Tag 
    WHERE Process.tblRelatedStructure.RelationshipPath IN (", paste0(includedRelationshipPaths, collapse=","), ") 
      AND (Process.tblRelatedValuesArchive.AlgorithmVersion IN (SELECT TOP (2) AlgorithmVersion FROM Process.tblRelatedValuesArchive AS tblRelatedValuesArchive_1 
    GROUP BY AlgorithmVersion ORDER BY AlgorithmVersion DESC))")

# sql <- paste("SELECT Process.tblRelatedValuesArchive.ID, Process.tblRelatedValuesArchive.AlgorithmVersion, Process.tblRelatedStructure.RelationshipPath, Process.tblRelatedValuesArchive.Subject1Tag, Process.tblRelatedValuesArchive.Subject2Tag, Process.tblRelatedValuesArchive.MultipleBirth, Process.tblRelatedValuesArchive.IsMz, Process.tblRelatedValuesArchive.Subject1LastSurvey, Process.tblRelatedValuesArchive.Subject2LastSurvey, Process.tblRelatedValuesArchive.RImplicitPass1, Process.tblRelatedValuesArchive.RImplicit, Process.tblRelatedValuesArchive.RImplicitSubject, Process.tblRelatedValuesArchive.RImplicitMother, Process.tblRelatedValuesArchive.RImplicit2004, Process.tblRelatedValuesArchive.RExplicitOldestSibVersion, Process.tblRelatedValuesArchive.RExplicitYoungestSibVersion, Process.tblRelatedValuesArchive.RExplicitPass1, Process.tblRelatedValuesArchive.RExplicit, Process.tblRelatedValuesArchive.RPass1, Process.tblRelatedValuesArchive.R, Process.tblRelatedValuesArchive.RPeek 
#   FROM Process.tblRelatedValuesArchive INNER JOIN Process.tblRelatedStructure ON Process.tblRelatedValuesArchive.Subject1Tag = Process.tblRelatedStructure.Subject1Tag AND Process.tblRelatedValuesArchive.Subject2Tag = Process.tblRelatedStructure.Subject2Tag
#   WHERE Process.tblRelatedStructure.RelationshipPath IN (", paste0(includedRelationshipPaths, collapse=","), ") 
#     AND (Process.tblRelatedValuesArchive.AlgorithmVersion IN (26, 34))")

sql <- gsub(pattern="\\n", replacement=" ", sql)
sqlDescription <- "SELECT * FROM Process.tblArchiveDescription" #AlgorithmVersion, Description

startTime <- Sys.time()
channel <- odbcConnect(dsn="BeeNlsLinks")
odbcGetInfo(channel)

dsRaw <- sqlQuery(channel, sql, stringsAsFactors=F)
dsDescription <- sqlQuery(channel, sqlDescription, stringsAsFactors=F)
odbcCloseAll()
(elapsedTime <- Sys.time() - startTime)
nrow(dsRaw)

olderVersionNumber <- min(dsRaw$AlgorithmVersion)
olderDescription <- dsDescription[dsDescription$AlgorithmVersion==olderVersionNumber, 'Description']
newerVersionNumber <- max(dsRaw$AlgorithmVersion)
newerDescription <- dsDescription[dsDescription$AlgorithmVersion==newerVersionNumber, 'Description']

columnsToConsider <- c("RImplicit2004", "RImplicit", "RExplicit")
# dsLatestGen2Sibs <- dsRaw[dsRaw$AlgorithmVersion==newerVersionNumber & dsRaw$RelationshipPath %in% includedRelationshipPaths, ]
# dsPreviousGen2Sibs <- dsRaw[dsRaw$AlgorithmVersion==olderVersionNumber & dsRaw$RelationshipPath %in% includedRelationshipPaths, ]
dsLatest <- dsRaw[dsRaw$AlgorithmVersion==newerVersionNumber & dsRaw$RelationshipPath %in% includedRelationshipPaths, ]
dsPrevious <- dsRaw[dsRaw$AlgorithmVersion==olderVersionNumber & dsRaw$RelationshipPath %in% includedRelationshipPaths, ]


dsCollapsedLatest <- ddply(dsLatest, .variables=columnsToConsider, .fun=nrow)
colnames(dsCollapsedLatest)[ncol(dsCollapsedLatest)]<- "Count"
dsCollapsedLatest <- dsCollapsedLatest[order(-dsCollapsedLatest$Count),]

dsCollapsedPrevious <- ddply(dsPrevious, .variables=columnsToConsider, .fun=nrow)
colnames(dsCollapsedPrevious)[ncol(dsCollapsedPrevious)]<- "Count"
dsCollapsedPrevious <- dsCollapsedPrevious[order(-dsCollapsedPrevious$Count), ]

ds <- merge(x=dsCollapsedLatest, y=dsCollapsedPrevious, by=columnsToConsider, all=T)
ds[is.na(ds$Count.x), "Count.x"] <- 0
ds[is.na(ds$Count.y), "Count.y"] <- 0
ds$Delta <- ds$Count.x - ds$Count.y
ds <- ds[ , -which(colnames(ds)=="Count.y")]
colnames(ds)[which(colnames(ds)=="Count.x")] <- "Count"
ds <- ds[order(-ds$Count, ds$Delta), c(4,1,2,3,5)]

colorGood <- "goodColor"
colorSoso <- "sosoColor"
colorBad <- "badColor"
colorNull <- "nullColor"

idGoodRows <- which(ds$RImplicit==ds$RExplicit)# & (ds$RImplicit2004 !=.375 | is.na(ds$RImplicit2004)))
#idSosoRows <- which(ds$RImplicit==ds$RExplicit & ds$RImplicit2004 ==.375)
idSosoRows <- which((ds$RImplicit==.375 | is.na(ds$RImplicit)) & !is.na(ds$RExplicit))
idBadRows <- which(abs(ds$RImplicit - ds$RExplicit) >= .25)# & ds$RImplicit!=1)
idNullRows <- which(is.na(ds$RImplicit) & is.na(ds$RExplicit))


idRows <- c(idGoodRows, idSosoRows, idBadRows, idNullRows) -1 #Subtract one, b/c LaTeX row indices are zero-based
idRowsList <- as.list(idRows)# as.list(unlist(idRows))
colorRows <- c(rep(colorGood, length(idGoodRows)), rep(colorSoso, length(idSosoRows)), rep(colorBad, length(idBadRows)), rep(colorNull, length(idNullRows)))
colorRows <- paste0("\\rowcolor{", colorRows, "} ")

PrintConditionalTable <- function(  ) {
  digitsFormat <- c(0, 0, 3, 3, 3, 0) #Include a dummy at the beginning, for the row.names.
  textTable <- xtable(ds, digits=digitsFormat, caption="Conditional Frequencies of $R$")
  #print(textTable, include.rownames=F, add.to.row=list(list(0, 1), c("\\rowcolor[gray]{.8} ", "\\rowcolor[gray]{.8} ")))
  #print(textTable, include.rownames=F, add.to.row=list(list(0, 1), c("\\rowcolor{blue} ", "\\rowcolor[gray]{.8} ")))
  #print(textTable, include.rownames=F, add.to.row=list(list(10, 1), c("\\rowcolor{goodColor} ", "\\rowcolor{badColor} ")))
  print(textTable, include.rownames=F, add.to.row=list(idRowsList, colorRows), NA.string="-")#, size="small")
}


CreateMarginalTable  <- function( relationshipPathID ) {
  dsLatest <- dsLatest[dsLatest$RelationshipPath==relationshipPathID, ]
  
  
  dsImplicitTable <- data.frame(table(dsLatest$RImplicit, useNA="always"))
  dsImplicit2004Table <- data.frame(table(dsLatest$RImplicit2004, useNA="always"))
  dsExplicitTable <- data.frame(table(dsLatest$RExplicit, useNA="always"))
  dsRTable <- data.frame(table(dsLatest$R, useNA="always"))
  
  dsTable <- merge(x=dsImplicit2004Table, y=dsImplicitTable, by="Var1", all=T)
  colnames(dsTable)[colnames(dsTable)=="Freq.x"] <- "Implicit2004"
  colnames(dsTable)[colnames(dsTable)=="Freq.y"] <- "Implicit"
  
  dsTable <- merge(x=dsTable, y=dsExplicitTable, by="Var1", all=T)
  colnames(dsTable)[colnames(dsTable)=="Freq"] <- "Explicit"
  dsTable <- merge(x=dsTable, y=dsRTable, by="Var1", all=T)
  colnames(dsTable)[colnames(dsTable)=="Freq"] <- "Eventual"
  colnames(dsTable)[colnames(dsTable)=="Var1"] <- "R"
  return( dsTable )

}
# CreateMarginalTable(1)
# CreateMarginalTable(2)

#dsTable <- dsTable[order(dsTable$R), ]
# dsTable

PrintMarginalTable <- function( relationshipPathID ) {
  dsTable <- CreateMarginalTable(relationshipPathID)
  textTable <- xtable(dsTable, caption=paste("Frequencies for RelationshipPath", relationshipPathID, "(single-entered)"))
  print(textTable, include.rownames=F, NA.string="-", size="large", add.to.col=list(list(0, 1), c("\\rowcolor[gray]{.8} ", "\\rowcolor[gray]{.8} ")))
}
#PrintMarginalTable()
# PrintMarginalTable(1)
#  PrintMarginalTable(2)

goodSumLatest <- sum(ds[idGoodRows, "Count"])
badSumLatest <- sum(ds[idBadRows, "Count"])

goodSumPrevious <- goodSumLatest - sum(ds[idGoodRows, "Delta"])
badSumPrevious <- badSumLatest - sum(ds[idBadRows, "Delta"])
dsRoc <- data.frame(Version=c(newerVersionNumber, olderVersionNumber), Good=c(goodSumLatest, goodSumPrevious), Bad=c(badSumLatest, badSumPrevious))

rocLag1 <- ggplot(dsRoc, aes(y=Good, x=Bad, label=Version)) +
   layer(geom="path") + layer(geom="text") #+
  # coord_cartesian(xlim=c(0, 8000), ylim=c(0, 8000))#+ #xlim(0, 8000)
  