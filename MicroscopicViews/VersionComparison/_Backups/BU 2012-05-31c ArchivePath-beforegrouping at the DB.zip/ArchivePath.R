rm(list=ls(all=TRUE))
require(RODBC)
require(ggplot2)
require(colorspace)
includedRelationshipPaths <- c(2)

startTime <- Sys.time()
# sql <- "SELECT     Process.tblRelatedStructure.RelationshipPath, Process.tblRelatedValuesArchive.RImplicit, Process.tblRelatedValuesArchive.RExplicit, 
#                       Process.tblRelatedValuesArchive.AlgorithmVersion, COUNT(Process.tblRelatedValuesArchive.ID) AS Count
# FROM         Process.tblRelatedValuesArchive INNER JOIN
#                       Process.tblRelatedStructure ON Process.tblRelatedValuesArchive.Subject1Tag = Process.tblRelatedStructure.Subject1Tag AND 
#                       Process.tblRelatedValuesArchive.Subject2Tag = Process.tblRelatedStructure.Subject2Tag
# GROUP BY Process.tblRelatedStructure.RelationshipPath, Process.tblRelatedValuesArchive.RImplicit, Process.tblRelatedValuesArchive.RExplicit, 
#                       Process.tblRelatedValuesArchive.AlgorithmVersion"

sql <- "SELECT     Process.tblRelatedValuesArchive.ID, Process.tblRelatedValuesArchive.AlgorithmVersion, Process.tblRelatedStructure.RelationshipPath, Process.tblRelatedValuesArchive.Subject1Tag, 
                      Process.tblRelatedValuesArchive.Subject2Tag, Process.tblRelatedValuesArchive.MultipleBirth, Process.tblRelatedValuesArchive.IsMz, 
                      Process.tblRelatedValuesArchive.Subject1LastSurvey, Process.tblRelatedValuesArchive.Subject2LastSurvey, Process.tblRelatedValuesArchive.RImplicitPass1, 
                      Process.tblRelatedValuesArchive.RImplicit, Process.tblRelatedValuesArchive.RImplicitSubject, Process.tblRelatedValuesArchive.RImplicitMother, 
                      Process.tblRelatedValuesArchive.RImplicit2004, Process.tblRelatedValuesArchive.RExplicitOldestSibVersion, 
                      Process.tblRelatedValuesArchive.RExplicitYoungestSibVersion, Process.tblRelatedValuesArchive.RExplicitPass1, Process.tblRelatedValuesArchive.RExplicit, 
                      Process.tblRelatedValuesArchive.RPass1, Process.tblRelatedValuesArchive.R, Process.tblRelatedValuesArchive.RPeek                  
FROM         Process.tblRelatedValuesArchive INNER JOIN
                      Process.tblRelatedStructure ON Process.tblRelatedValuesArchive.Subject1Tag = Process.tblRelatedStructure.Subject1Tag AND 
                      Process.tblRelatedValuesArchive.Subject2Tag = Process.tblRelatedStructure.Subject2Tag"
channel <- odbcConnect(dsn="BeeNlsLinks")
odbcGetInfo(channel)
dsRaw <- sqlQuery(channel, sql, stringsAsFactors=F)
odbcCloseAll()
dsRaw <- dsRaw[dsRaw$RelationshipPath %in% includedRelationshipPaths, ]

versionNumbers <- sort(unique(dsRaw$AlgorithmVersion))
columnsToConsider <- c("RImplicit2004", "RImplicit", "RExplicit")
dsRoc <- data.frame(Version=versionNumbers, Good=NA_integer_, Bad=NA_integer_)

for( versionNumber in versionNumbers ) {c
  dsSlice <- dsRaw[dsRaw$AlgorithmVersion==versionNumber, columnsToConsider]
  
  goodSum <- sum(dsSlice$RImplicit==dsSlice$RExplicit, na.rm=T)
  badSum <- sum(abs(dsSlice$RImplicit - dsSlice$RExplicit) >= .25, na.rm=T)
  dsRoc[dsRoc$Version==versionNumber, c("Good", "Bad")] <- c(goodSum, badSum)
}


# if( names(dev.cur()) != "null device" ) dev.off()
# deviceWidth <- 10#6.5#10#20
# heightToWidthRatio <- .75
# windows(width=deviceWidth, height=deviceWidth*heightToWidthRatio)
#dsRoc$ColorVersion <- sequential_hcl(n=length(versionNumbers))
#colorVersion <- factor(sequential_hcl(n=length(versionNumbers)))
#names(colorVersion) <- versionNumbers
colorVersion <- (sequential_hcl(n=length(versionNumbers), c=c(80, 80), l = c(90, 30)))
ggplot(dsRoc, aes(y=Good, x=Bad, label=Version, color=Version)) + #scale_color_brewer()+
  scale_colour_gradientn(colours=colorVersion) +#, color=ColorVersion)
   layer(geom="path") + 
   layer(geom="text") +
   coord_equal() + opts(legend.position = "none") 
#   coord_cartesian(xlim=c(0, 8000), ylim=c(0, 8000))#+
#   coord_trans(xtrans="log10")
  #xlim(0, 8000)
  #scale_x_continuous(trans="log10")# + scale_y_continuous(trans="log10") #limits=c(0, 4),
(elapsed <- Sys.time() - startTime)