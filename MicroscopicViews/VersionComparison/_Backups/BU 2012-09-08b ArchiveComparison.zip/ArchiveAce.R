## @knitr Setup
rm(list=ls(all=TRUE))
library(NlsyLinks)
library(RODBC)
library(ggplot2)
library(colorspace)
library(xtable)

oName <- "MathStandardized"
oName_1 <- paste0(oName, "_1")
oName_2 <- paste0(oName, "_2")
relationshipPath <- 2
rVersions <- c("R", "RPass1", "RImplicit", "RImplicitPass1", "RExplicit", "RExplicitPass1", "RImplicit2004")

suppressGroupTables <- FALSE

# sql <- paste("SELECT Process.tblRelatedValuesArchive.AlgorithmVersion,  Process.tblRelatedValuesArchive.Subject1Tag, Process.tblRelatedValuesArchive.Subject2Tag, Process.tblRelatedValuesArchive.R
sql <- paste("SELECT Process.tblRelatedValuesArchive.AlgorithmVersion, Process.tblRelatedStructure.RelationshipPath, Process.tblRelatedValuesArchive.Subject1Tag, Process.tblRelatedValuesArchive.Subject2Tag,Process.tblRelatedValuesArchive.RImplicitPass1, Process.tblRelatedValuesArchive.RImplicit, Process.tblRelatedValuesArchive.RImplicitSubject, Process.tblRelatedValuesArchive.RImplicitMother, Process.tblRelatedValuesArchive.RImplicit2004, Process.tblRelatedValuesArchive.RExplicitPass1, Process.tblRelatedValuesArchive.RExplicit, Process.tblRelatedValuesArchive.RPass1, Process.tblRelatedValuesArchive.R
  FROM Process.tblRelatedValuesArchive INNER JOIN Process.tblRelatedStructure ON Process.tblRelatedValuesArchive.Subject1Tag = Process.tblRelatedStructure.Subject1Tag AND Process.tblRelatedValuesArchive.Subject2Tag = Process.tblRelatedStructure.Subject2Tag 
    WHERE Process.tblRelatedStructure.RelationshipPath = ", relationshipPath, " 
      AND (Process.tblRelatedValuesArchive.AlgorithmVersion IN (SELECT TOP (2) AlgorithmVersion FROM Process.tblRelatedValuesArchive AS tblRelatedValuesArchive_1 
    GROUP BY AlgorithmVersion ORDER BY AlgorithmVersion DESC))")
sql <- gsub(pattern="\\n", replacement=" ", sql)
sqlDescription <- "SELECT * FROM Process.tblArchiveDescription" #AlgorithmVersion, Description

startTime <- Sys.time()
channel <- odbcConnect(dsn="BeeNlsLinks")
# odbcGetInfo(channel)

dsRaw <- sqlQuery(channel, sql, stringsAsFactors=F)
dsDescription <- sqlQuery(channel, sqlDescription, stringsAsFactors=F)
odbcCloseAll()
elapsedTime <- Sys.time() - startTime
# print(elapsedTime)
# nrow(dsRaw)

olderVersionNumber <- min(dsRaw$AlgorithmVersion)
olderDescription <- dsDescription[dsDescription$AlgorithmVersion==olderVersionNumber, 'Description']
newerVersionNumber <- max(dsRaw$AlgorithmVersion)
newerDescription <- dsDescription[dsDescription$AlgorithmVersion==newerVersionNumber, 'Description']

dsLinkingNewer <- dsRaw[dsRaw$AlgorithmVersion==newerVersionNumber, ]
dsLinkingOlder <- dsRaw[dsRaw$AlgorithmVersion==olderVersionNumber, ]
rm(dsRaw)

dsOutcomes <- ExtraOutcomes79[, c("SubjectTag", "MathStandardized", "WeightStandardizedForAge19To25")]

dsDirtyNewer <- CreatePairLinksSingleEntered(outcomeDataset=dsOutcomes, linksPairDataset=dsLinkingNewer, linksNames=rVersions, outcomeNames=c("MathStandardized", "WeightStandardizedForAge19To25"))
dsDirtyOlder <- CreatePairLinksSingleEntered(outcomeDataset=dsOutcomes, linksPairDataset=dsLinkingOlder, linksNames=rVersions, outcomeNames=c("MathStandardized", "WeightStandardizedForAge19To25"))
rm(dsOutcomes, dsLinkingNewer, dsLinkingOlder)

# dsGroupSummaryNewer <- RGroupSummary(dsDirtyNewer, oName_1, oName_2)
# dsGroupSummaryOlder <- RGroupSummary(dsDirtyOlder, oName_1, oName_2)
# dsGroupSummaryNewer

PrintGroupSummary <- function( dsSummary, title="Group Summary"  ) {
  colnames(dsSummary)[colnames(dsSummary)=="PairCount"] <- "Pairs"
  colnames(dsSummary)[colnames(dsSummary)=="O1Variance"] <- "Var1"
  colnames(dsSummary)[colnames(dsSummary)=="O2Variance"] <- "Var2"
  colnames(dsSummary)[colnames(dsSummary)=="O1O2Covariance"] <- "Cov"
  colnames(dsSummary)[colnames(dsSummary)=="Correlation"] <- "Cor"
  digitsFormat <- c(0,3,0,0,2,2,2,2,1,0) #Include a dummy at the beginning, for the row.names.
  textTable <- xtable(dsSummary, caption=title, digits=digitsFormat)
  print(textTable, include.rownames=F, size="large")
}
# PrintGroupSummary(dsSummary=dsGroupSummaryNewer)

## @knitr EvalGroup
dsAce <- data.frame(Version=rVersions, NewASq=NA_real_, NewCSq=NA_real_, NewESq=NA_real_, OldASq=NA_real_, OldCSq=NA_real_, OldESq=NA_real_)
#for( rVersion in rVersions ) {
for( i in seq_along(rVersions) ) {
  rVersion <- rVersions[i]
#   print(rVersion)
  dsGroupSummaryNewer <- RGroupSummary(dsDirtyNewer, oName_1, oName_2, rName=rVersion)
  dsGroupSummaryOlder <- RGroupSummary(dsDirtyOlder, oName_1, oName_2, rName=rVersion)
  
  if( !suppressGroupTables ) {
    PrintGroupSummary(dsGroupSummaryNewer, title=paste(rVersion, "-- Newer Version"))
    PrintGroupSummary(dsGroupSummaryOlder, title=paste(rVersion, "-- Older Version"))
  }
   
  dsCleanNewer <- CleanSemAceDataset(dsDirty=dsDirtyNewer, dsGroupSummaryNewer, oName_1, oName_2, rName=rVersion)
  dsCleanOlder <- CleanSemAceDataset(dsDirty=dsDirtyOlder, dsGroupSummaryOlder, oName_1, oName_2, rName=rVersion)
  
  aceNewer <- AceLavaanGroup(dsCleanNewer)
  aceOlder <- AceLavaanGroup(dsCleanOlder)   

  dsAce[i, 2:7] <- c(aceNewer@ASquared, aceNewer@CSquared, aceNewer@ESquared, aceOlder@ASquared, aceOlder@CSquared, aceOlder@ESquared)
}
# dsAce

## @knitr EvalAce
PrintAces <- function(  ) {
  digitsFormat <- c(0,1,3,3,3,3,3,3) #Include a dummy at the beginning, for the row.names.
  textTable <- xtable(dsAce, caption="Comparison of R Versions", digits=digitsFormat)
  print(textTable, include.rownames=F, size="large")
}
# PrintAces()
# summary(dsAce)

# 

# rm(dsCleanNewer, dsCleanOlder)
# aceNewer
# rm(dsDirtyNewer, dsDirtyOlder)

